package com.zex.dungeonsdimension;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ChatComponentText;
import net.minecraft.world.World;

/** A placeable crystal block; right-clicking it activates a nearby complete Shadowstone frame. */
public class BlockSunCrystal extends Block {
    public BlockSunCrystal() {
        super(Material.glass);
        setBlockName("sunCrystalBlock");
        setBlockTextureName(DungeonsDimension.MODID + ":sun_crystal_block");
        setHardness(1.0F);
        setLightLevel(0.9F);
        setStepSound(Block.soundTypeGlass);
    }

    @Override public boolean isOpaqueCube() { return false; }
    @Override public boolean renderAsNormalBlock() { return false; }

    @Override public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int side, float hitX, float hitY, float hitZ) {
        if (world.isRemote) return true;
        boolean activated = false;
        // Nether-like frame: 2x3 interior, 4x5 outer dimensions; corners may be omitted.
        for (int axis = 0; axis < 2 && !activated; axis++) {
            for (int bx = x - 5; bx <= x + 5 && !activated; bx++) {
                for (int by = y - 5; by <= y + 2 && !activated; by++) {
                    for (int bz = z - 5; bz <= z + 5 && !activated; bz++) {
                        if (validFrame(world, bx, by, bz, axis)) {
                            fillPortal(world, bx, by, bz, axis);
                            activated = true;
                        }
                    }
                }
            }
        }
        if (activated) player.addChatMessage(new ChatComponentText("Cristal Solar ativado! O portal para Dungeons foi aberto."));
        else player.addChatMessage(new ChatComponentText("Construa uma moldura completa de Pedra Sombria perto do Cristal Solar."));
        return true;
    }

    private boolean isFrame(World w, int x, int y, int z) {
        return w.getBlock(x, y, z) == DimensionContent.shadowstone;
    }
    private int px(int x, int z, int offset, int axis) { return x + (axis == 0 ? offset : 0); }
    private int pz(int x, int z, int offset, int axis) { return z + (axis == 1 ? offset : 0); }

    private boolean validFrame(World w, int x, int y, int z, int axis) {
        // x,y,z is the lower-left outer corner; the interior is 2 wide x 3 high.
        for (int xx = 0; xx < 4; xx++) {
            for (int yy = 0; yy < 5; yy++) {
                boolean edge = (xx == 0 || xx == 3 || yy == 0 || yy == 4);
                int wx = px(x, z, xx, axis), wz = pz(x, z, xx, axis);
                if (edge) {
                    // Nether portal corners are optional.
                    boolean corner = (xx == 0 || xx == 3) && (yy == 0 || yy == 4);
                    if (!corner && !isFrame(w, wx, y + yy, wz)) return false;
                } else if (!w.isAirBlock(wx, y + yy, wz) && w.getBlock(wx, y + yy, wz) != this && w.getBlock(wx, y + yy, wz) != DimensionContent.dungeonsPortal) return false;
            }
        }
        return true;
    }

    private void fillPortal(World w, int x, int y, int z, int axis) {
        for (int xx = 1; xx <= 2; xx++) for (int yy = 1; yy <= 3; yy++) {
            w.setBlock(px(x, z, xx, axis), y + yy, pz(x, z, xx, axis), DimensionContent.dungeonsPortal, axis, 2);
        }
    }
}
