package com.zex.dungeonsdimension;

import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.item.Item;
import net.minecraft.creativetab.CreativeTabs;

/** Initial original blocks and materials for the adventure realm. */
public final class DimensionContent {
    public static Block astralLog, astralLeaves, astralPlanks, moonstoneOre, shadowstone, sunCrystalBlock, dungeonsPortal;
    public static Item moonstone, sunCrystal, astralIngot;
    private DimensionContent() {}
    public static void register() {
        astralLog = new Block(Material.wood).setBlockName("astralLog").setBlockTextureName(DungeonsDimension.MODID + ":astral_log").setHardness(2.0F).setStepSound(Block.soundTypeWood).setCreativeTab(CreativeTabs.tabBlock);
        astralLeaves = new Block(Material.leaves).setBlockName("astralLeaves").setBlockTextureName(DungeonsDimension.MODID + ":astral_leaves").setHardness(0.2F).setLightOpacity(1).setCreativeTab(CreativeTabs.tabBlock);
        astralPlanks = new Block(Material.wood).setBlockName("astralPlanks").setBlockTextureName(DungeonsDimension.MODID + ":astral_planks").setHardness(2.0F).setStepSound(Block.soundTypeWood).setCreativeTab(CreativeTabs.tabBlock);
        moonstoneOre = new Block(Material.rock).setBlockName("moonstoneOre").setBlockTextureName(DungeonsDimension.MODID + ":moonstone_ore").setHardness(3.0F).setResistance(5.0F).setHarvestLevel("pickaxe", 2).setCreativeTab(CreativeTabs.tabBlock);
        shadowstone = new Block(Material.rock).setBlockName("shadowstone").setBlockTextureName(DungeonsDimension.MODID + ":shadowstone").setHardness(2.5F).setCreativeTab(CreativeTabs.tabBlock);
        moonstone = new Item().setUnlocalizedName("moonstone").setTextureName(DungeonsDimension.MODID + ":moonstone").setCreativeTab(CreativeTabs.tabMaterials);
        sunCrystalBlock = new BlockSunCrystal().setCreativeTab(CreativeTabs.tabBlock);
        dungeonsPortal = new BlockDungeonsPortal();
        sunCrystal = new Item().setUnlocalizedName("sunCrystal").setTextureName(DungeonsDimension.MODID + ":sun_crystal").setCreativeTab(CreativeTabs.tabMaterials);
        astralIngot = new Item().setUnlocalizedName("astralIngot").setTextureName(DungeonsDimension.MODID + ":astral_ingot").setCreativeTab(CreativeTabs.tabMaterials);
        GameRegistry.registerBlock(astralLog, "astral_log"); GameRegistry.registerBlock(astralLeaves, "astral_leaves");
        GameRegistry.registerBlock(astralPlanks, "astral_planks"); GameRegistry.registerBlock(moonstoneOre, "moonstone_ore"); GameRegistry.registerBlock(shadowstone, "shadowstone");
        GameRegistry.registerBlock(sunCrystalBlock, "sun_crystal_block"); GameRegistry.registerBlock(dungeonsPortal, "dungeons_portal");
        GameRegistry.registerItem(moonstone, "moonstone"); GameRegistry.registerItem(sunCrystal, "sun_crystal"); GameRegistry.registerItem(astralIngot, "astral_ingot");
    }
}
