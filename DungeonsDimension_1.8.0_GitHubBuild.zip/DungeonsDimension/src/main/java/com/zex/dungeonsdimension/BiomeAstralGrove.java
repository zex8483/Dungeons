package com.zex.dungeonsdimension;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.init.Blocks;
/** Original biome concept: Astral Grove. */
public class BiomeAstralGrove extends BiomeGenBase {
    public BiomeAstralGrove(int id) { super(id); setBiomeName("Astral Grove"); setColor(0x6A3D91); setTemperatureRainfall(0.75F, 0.8F); topBlock = DimensionContent.astralPlanks; fillerBlock = DimensionContent.shadowstone; theBiomeDecorator.treesPerChunk = 5; theBiomeDecorator.grassPerChunk = 4; }
}
