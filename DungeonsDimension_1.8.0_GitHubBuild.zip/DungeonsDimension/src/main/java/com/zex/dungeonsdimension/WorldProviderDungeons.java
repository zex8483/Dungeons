package com.zex.dungeonsdimension;

import net.minecraft.world.WorldProviderHell;

/** First playable prototype: uses the stable 1.7.10 Nether terrain generator as a dark dungeon realm. */
public class WorldProviderDungeons extends WorldProviderHell {
    @Override
    public String getDimensionName() {
        return "Dungeons Dimension";
    }

    @Override
    public String getWelcomeMessage() {
        return "You entered the Dungeons Dimension...";
    }

    @Override
    public String getDepartMessage() {
        return "You escaped the Dungeons Dimension.";
    }
}
