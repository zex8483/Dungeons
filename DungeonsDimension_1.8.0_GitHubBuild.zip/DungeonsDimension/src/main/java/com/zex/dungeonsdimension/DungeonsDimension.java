package com.zex.dungeonsdimension;

import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.Mod.EventHandler;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.event.FMLPostInitializationEvent;
import cpw.mods.fml.common.network.NetworkRegistry;
import net.minecraftforge.common.MinecraftForge;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.common.SidedProxy;
import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraftforge.common.DimensionManager;

@Mod(modid = DungeonsDimension.MODID, name = DungeonsDimension.NAME, version = DungeonsDimension.VERSION)
public class DungeonsDimension {
    public static final String MODID = "dungeonsdimension";
    public static final String NAME = "Dungeons Dimension";
    public static final String VERSION = "1.8.0";
    public static final int DIMENSION_ID = 37;
    public static Item dungeonKey;
    public static DungeonsDimension INSTANCE;

    @EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        INSTANCE = this;
        DimensionContent.register();
        GameRegistry.registerWorldGenerator(new WorldGenDimensionFeatures(), 10);
        dungeonKey = new ItemDungeonKey().setUnlocalizedName("dungeonKey").setTextureName(MODID + ":dungeon_key").setCreativeTab(CreativeTabs.tabTools);
        GameRegistry.registerItem(dungeonKey, "dungeon_key");
        GameRegistry.registerWorldGenerator(new WorldGenDungeon(), 20);
        DimensionManager.registerProviderType(DIMENSION_ID, WorldProviderDungeons.class, false);
        DimensionManager.registerDimension(DIMENSION_ID, DIMENSION_ID);
    }

    @EventHandler
    public void init(FMLInitializationEvent event) {
        NetworkRegistry.INSTANCE.registerGuiHandler(this, new DungeonsGuiHandler());
        // Inventory screen events exist on the client only.
        if (event.getSide().isClient()) {
            MinecraftForge.EVENT_BUS.register(new InventoryAccessoryButton());
        }
    }
}
