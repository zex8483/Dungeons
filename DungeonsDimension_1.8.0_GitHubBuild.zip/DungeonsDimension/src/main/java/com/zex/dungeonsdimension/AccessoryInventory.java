package com.zex.dungeonsdimension;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.InventoryBasic;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;

/** Six accessory slots saved in the player's persistent entity data. */
public class AccessoryInventory extends InventoryBasic {
    public static final int SLOT_COUNT = 6;
    private static final String NBT_KEY = "DungeonsDimensionAccessories";
    private final EntityPlayer owner;

    public AccessoryInventory(EntityPlayer player) {
        super("Dungeons Dimension Accessories", false, SLOT_COUNT);
        this.owner = player;
        loadFromPlayer();
    }

    private void loadFromPlayer() {
        NBTTagCompound data = owner.getEntityData();
        if (!data.hasKey(NBT_KEY)) return;
        NBTTagList list = data.getTagList(NBT_KEY, 10);
        for (int i = 0; i < list.tagCount(); i++) {
            NBTTagCompound entry = list.getCompoundTagAt(i);
            int slot = entry.getByte("Slot") & 255;
            if (slot >= 0 && slot < SLOT_COUNT) {
                ItemStack stack = ItemStack.loadItemStackFromNBT(entry);
                if (stack != null) super.setInventorySlotContents(slot, stack);
            }
        }
    }

    @Override public void markDirty() {
        NBTTagList list = new NBTTagList();
        for (int slot = 0; slot < SLOT_COUNT; slot++) {
            ItemStack stack = getStackInSlot(slot);
            if (stack != null) {
                NBTTagCompound entry = new NBTTagCompound();
                entry.setByte("Slot", (byte) slot);
                stack.writeToNBT(entry);
                list.appendTag(entry);
            }
        }
        owner.getEntityData().setTag(NBT_KEY, list);
        super.markDirty();
    }

    @Override public boolean isItemValidForSlot(int slot, ItemStack stack) {
        return slot >= 0 && slot < SLOT_COUNT && stack != null;
    }
}
