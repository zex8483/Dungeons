package com.zex.dungeonsdimension;
import java.util.Random;
import cpw.mods.fml.common.IWorldGenerator;
import net.minecraft.world.World;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.feature.WorldGenMinable;
import net.minecraft.init.Blocks;
/** Adds original ores and simple astral tree clusters to the adventure dimension. */
public class WorldGenDimensionFeatures implements IWorldGenerator {
 public void generate(Random r,int cx,int cz,World w,IChunkProvider cg,IChunkProvider cp) {
  if(w.provider.dimensionId != DungeonsDimension.DIMENSION_ID || w.isRemote) return;
  int x=cx*16+r.nextInt(16), z=cz*16+r.nextInt(16);
  for(int i=0;i<5;i++){ int y=8+r.nextInt(90); new WorldGenMinable(DimensionContent.moonstoneOre,5,Blocks.netherrack).generate(w,r,x,y,z); }
  if(r.nextInt(3)==0){ int y=w.getTopSolidOrLiquidBlock(x,z); if(y>4 && y<120){ for(int dy=0;dy<4;dy++) w.setBlock(x,y+dy,z,DimensionContent.astralLog,0,2); for(int dx=-2;dx<=2;dx++) for(int dz=-2;dz<=2;dz++) for(int dy=2;dy<=5;dy++) if(r.nextBoolean() && Math.abs(dx)+Math.abs(dz)<4) w.setBlock(x+dx,y+dy,z+dz,DimensionContent.astralLeaves,0,2); }}
 }
}
