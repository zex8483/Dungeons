# Dungeons Dimension — v1.8.0 source prototype (Minecraft Java 1.7.10 / Forge)

## New realm content in this source update
- New registered blocks: Astral Log, Astral Leaves, Astral Planks, Moonstone Ore, Shadowstone.
- New items/materials: Moonstone, Sun Crystal, Astral Ingot.
- Original 16x16 pixel textures and Portuguese/English names.
- Initial dimension-only world generator for Moonstone Ore and simple Astral tree clusters.
- Added an Astral Grove biome class as a design foundation.

## Important limitations
This is still an **uncompiled, untested source project**, not a ready-to-install JAR. The current dimension provider still inherits the 1.7.10 Nether provider as a terrain placeholder; the Astral Grove biome is registered as code foundation but is not yet wired into a custom biome/terrain pipeline. The tree generator is a simple log-and-leaf cluster, not a full tree feature. Bosses, more biomes, spawn positioning and full progression are still future work.

## Build
Requires a compatible Java 7/8 setup and legacy ForgeGradle 1.2 dependencies. Try `gradlew setupDecompWorkspace build` in a compatible environment. No build/test has been confirmed here.


## Portal de Pedra Sombria (v1.8.0)
- Monte uma moldura vertical de Pedra Sombria no formato do portal do Nether (interior de 2 blocos de largura por 3 de altura; cantos podem ficar vazios).
- Coloque o **Bloco de Cristal Solar** perto/em frente à moldura e clique com o botão direito nele.
- Se a moldura estiver válida, o interior será preenchido com o Portal de Dungeons.
- Entrar no portal tenta transportar o jogador entre o mundo normal e a dimensão Dungeons.

**Limitações conhecidas:** esta versão-fonte ainda não foi compilada nem testada em jogo. A geração da dimensão ainda usa o terreno Nether como base, e a detecção do portal precisa ser validada no Forge 1.7.10. O item antigo Cristal Solar continua no criativo como item separado, além do novo bloco.

## Compilar pelo GitHub Actions (celular também)

1. Crie um repositório no GitHub e envie o conteúdo desta pasta para a raiz do repositório (incluindo `.github/workflows/build.yml`).
2. Abra a aba **Actions** do repositório.
3. Escolha **Build Dungeons Dimension** e toque em **Run workflow** (ou envie um commit para `main`/`master`).
4. Se a compilação terminar com sucesso, abra a execução e baixe o artefato **DungeonsDimension-1.8.0** na seção **Artifacts**.

A compilação ainda precisa ser executada para confirmar compatibilidade. ForgeGradle 1.2 e Gradle 2.14.1 são ferramentas antigas e podem falhar em infraestrutura moderna; se isso ocorrer, consulte o log da etapa **Compilar mod Forge 1.7.10**. Não instale o ZIP do código-fonte como se fosse o mod JAR.
