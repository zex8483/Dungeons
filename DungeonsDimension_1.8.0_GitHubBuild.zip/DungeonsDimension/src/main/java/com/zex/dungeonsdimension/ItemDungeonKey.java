package com.zex.dungeonsdimension;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ChatComponentText;
import net.minecraft.world.World;
import net.minecraft.world.Teleporter;
import net.minecraftforge.common.DimensionManager;

public class ItemDungeonKey extends Item {
    public ItemDungeonKey() {
        setMaxStackSize(1);
    }

    @Override
    public ItemStack onItemRightClick(ItemStack stack, World world, EntityPlayer player) {
        if (!world.isRemote) {
            int targetDimension = player.dimension == DungeonsDimension.DIMENSION_ID ? 0 : DungeonsDimension.DIMENSION_ID;
            if (DimensionManager.getWorld(targetDimension) == null) {
                DimensionManager.initDimension(targetDimension);
            }
            player.addChatMessage(new ChatComponentText(targetDimension == 0 ? "Returning to the Overworld..." : "The Dungeon Key pulls you into another realm..."));
            player.travelToDimension(targetDimension);
        }
        return stack;
    }

    @SideOnly(Side.CLIENT)
    @Override
    public void addInformation(ItemStack stack, EntityPlayer player, List list, boolean advanced) {
        list.add("Right-click to enter or leave the Dungeons Dimension.");
        list.add("Prototype for Minecraft Forge 1.7.10");
    }
}
