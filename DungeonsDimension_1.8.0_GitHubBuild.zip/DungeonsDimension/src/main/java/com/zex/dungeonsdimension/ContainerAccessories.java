package com.zex.dungeonsdimension;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

public class ContainerAccessories extends Container {
    public final AccessoryInventory accessories;
    private final EntityPlayer owner;

    public ContainerAccessories(EntityPlayer player) {
        this.owner = player;
        this.accessories = new AccessoryInventory(player);
        // Six dedicated accessory slots, arranged in two rows of three.
        for (int row = 0; row < 2; row++) {
            for (int col = 0; col < 3; col++) {
                addSlotToContainer(new Slot(accessories, col + row * 3, 62 + col * 18, 31 + row * 22));
            }
        }
        // Player inventory and hotbar.
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlotToContainer(new Slot(player.inventory, col + row * 9 + 9, 8 + col * 18, 99 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlotToContainer(new Slot(player.inventory, col, 8 + col * 18, 157));
        }
    }

    @Override public boolean canInteractWith(EntityPlayer player) { return player == owner; }

    @Override public void onContainerClosed(EntityPlayer player) {
        super.onContainerClosed(player);
        accessories.markDirty();
    }

    @Override public ItemStack transferStackInSlot(EntityPlayer player, int index) {
        ItemStack original = null;
        if (index < 0 || index >= inventorySlots.size()) return null;
        Slot slot = (Slot) inventorySlots.get(index);
        if (slot != null && slot.getHasStack()) {
            ItemStack stack = slot.getStack();
            original = stack.copy();
            if (index < AccessoryInventory.SLOT_COUNT) {
                if (!mergeItemStack(stack, AccessoryInventory.SLOT_COUNT, inventorySlots.size(), true)) return null;
            } else {
                if (!mergeItemStack(stack, 0, AccessoryInventory.SLOT_COUNT, false)) return null;
            }
            if (stack.stackSize == 0) slot.putStack(null); else slot.onSlotChanged();
            if (stack.stackSize == original.stackSize) return null;
            slot.onPickupFromSlot(player, stack);
        }
        return original;
    }
}
