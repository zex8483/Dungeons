package com.zex.dungeonsdimension;

import cpw.mods.fml.common.network.IGuiHandler;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;

public class DungeonsGuiHandler implements IGuiHandler {
    public static final int ACCESSORIES_GUI = 1;
    @Override public Object getServerGuiElement(int id, EntityPlayer player, World world, int x, int y, int z) {
        if (id == ACCESSORIES_GUI) return new ContainerAccessories(player);
        return null;
    }
    @Override public Object getClientGuiElement(int id, EntityPlayer player, World world, int x, int y, int z) {
        if (id == ACCESSORIES_GUI) return new GuiAccessories(new ContainerAccessories(player));
        return null;
    }
}
