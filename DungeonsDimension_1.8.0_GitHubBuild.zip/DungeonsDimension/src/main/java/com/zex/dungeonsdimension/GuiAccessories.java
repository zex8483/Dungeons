package com.zex.dungeonsdimension;

import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class GuiAccessories extends GuiContainer {
    private static final ResourceLocation TEXTURE = new ResourceLocation("dungeonsdimension:textures/gui/accessories.png");

    public GuiAccessories(ContainerAccessories container) {
        super(container);
        xSize = 176;
        ySize = 194;
    }

    @Override protected void drawGuiContainerForegroundLayer(int mouseX, int mouseY) {
        fontRendererObj.drawString("Dungeons Dimension", 8, 7, 0xE6D7FF);
        fontRendererObj.drawString("Acessorios magicos", 8, 19, 0xB98AFF);
        fontRendererObj.drawString("Joias / Aneis / Reliquias", 8, 75, 0xE6D7FF);
        fontRendererObj.drawString("Inventario", 8, 85, 0xE6D7FF);
    }

    @Override protected void drawGuiContainerBackgroundLayer(float partialTicks, int mouseX, int mouseY) {
        GL11.glColor4f(1F, 1F, 1F, 1F);
        mc.getTextureManager().bindTexture(TEXTURE);
        int x = (width - xSize) / 2;
        int y = (height - ySize) / 2;
        drawTexturedModalRect(x, y, 0, 0, xSize, ySize);
    }
}
