package com.zex.dungeonsdimension;

import java.util.Random;
import cpw.mods.fml.common.IWorldGenerator;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.world.World;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.monster.EntitySkeleton;
import net.minecraft.entity.monster.EntitySpider;
import net.minecraft.entity.monster.EntityZombie;

/** Overworld dungeon prototype: three themed rooms with a named boss and loot chest. */
public class WorldGenDungeon implements IWorldGenerator {
    @Override
    public void generate(Random random, int chunkX, int chunkZ, World world,
                         IChunkProvider chunkGenerator, IChunkProvider chunkProvider) {
        if (world.provider.dimensionId != 0 || random.nextInt(72) != 0) return;
        int x = chunkX * 16 + 8;
        int z = chunkZ * 16 + 8;
        int y = world.getTopSolidOrLiquidBlock(x, z);
        if (y < 58 || y > 105) return;
        // Avoid building into water or lava at the structure's centre.
        if (world.isRemote || world.getBlock(x, y - 1, z) == Blocks.water || world.getBlock(x, y - 1, z) == Blocks.lava) return;
        buildDungeon(world, random, x, y, z, random.nextInt(3));
    }

    private void buildDungeon(World world, Random random, int x, int y, int z, int theme) {
        net.minecraft.block.Block wall = theme == 1 ? Blocks.nether_brick : (theme == 2 ? Blocks.cobblestone : Blocks.stonebrick);
        net.minecraft.block.Block trim = theme == 1 ? Blocks.nether_brick_fence : (theme == 2 ? Blocks.mossy_cobblestone : Blocks.mossy_stonebrick);
        // 11 x 7 x 11 chamber. The floor, ceiling and walls are solid; the entrance is open.
        for (int dx = -5; dx <= 5; dx++) {
            for (int dz = -5; dz <= 5; dz++) {
                for (int dy = 0; dy <= 6; dy++) {
                    int bx = x + dx, by = y + dy, bz = z + dz;
                    if (dy == 0 || dy == 6 || Math.abs(dx) == 5 || Math.abs(dz) == 5) {
                        world.setBlock(bx, by, bz, wall, 0, 2);
                    } else {
                        world.setBlockToAir(bx, by, bz);
                    }
                }
            }
        }
        world.setBlock(x, y + 1, z - 5, Blocks.air, 0, 2);
        world.setBlock(x, y + 2, z - 5, Blocks.air, 0, 2);
        world.setBlock(x - 3, y + 1, z + 3, trim, 0, 2);
        world.setBlock(x + 3, y + 1, z + 3, trim, 0, 2);
        world.setBlock(x - 3, y + 1, z - 3, trim, 0, 2);
        world.setBlock(x + 3, y + 1, z - 3, trim, 0, 2);

        // Chest at the rear; reward pool is vanilla-safe for Forge 1.7.10.
        world.setBlock(x, y + 1, z + 4, Blocks.chest, 0, 2);
        TileEntityChest chest = (TileEntityChest) world.getTileEntity(x, y + 1, z + 4);
        if (chest != null) fillLoot(chest, random, theme);

        EntityLiving boss;
        if (theme == 1) {
            EntitySkeleton skeleton = new EntitySkeleton(world);
            skeleton.setSkeletonType(0);
            equip(skeleton, Items.bow, Items.iron_boots, Items.iron_leggings, Items.iron_chestplate, Items.iron_helmet);
            configureBoss(skeleton, "Carrasco das Cinzas", 44.0D, 7.0D);
            boss = skeleton;
        } else if (theme == 2) {
            EntitySpider spider = new EntitySpider(world);
            configureBoss(spider, "Aranha Colossal", 56.0D, 8.0D);
            boss = spider;
        } else {
            EntityZombie zombie = new EntityZombie(world);
            equip(zombie, Items.iron_sword, Items.iron_boots, Items.iron_leggings, Items.iron_chestplate, Items.iron_helmet);
            configureBoss(zombie, "Guardião da Dungeon", 60.0D, 9.0D);
            boss = zombie;
        }
        boss.setPosition(x + 0.5D, y + 1.0D, z + 0.5D);
        world.spawnEntityInWorld(boss);
    }

    private void configureBoss(EntityLiving boss, String name, double health, double damage) {
        boss.setCustomNameTag(name);
        boss.setAlwaysRenderNameTag(true);
        boss.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(health);
        boss.setHealth((float) health);
        boss.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(damage);
        boss.getEntityAttribute(SharedMonsterAttributes.followRange).setBaseValue(32.0D);
        boss.getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(0.35D);
    }

    private void equip(EntityLiving entity, net.minecraft.item.Item held, net.minecraft.item.Item boots,
                       net.minecraft.item.Item leggings, net.minecraft.item.Item chestplate, net.minecraft.item.Item helmet) {
        entity.setCurrentItemOrArmor(0, new ItemStack(held));
        entity.setCurrentItemOrArmor(1, new ItemStack(boots));
        entity.setCurrentItemOrArmor(2, new ItemStack(leggings));
        entity.setCurrentItemOrArmor(3, new ItemStack(chestplate));
        entity.setCurrentItemOrArmor(4, new ItemStack(helmet));
    }

    private void fillLoot(TileEntityChest chest, Random random, int theme) {
        putRandom(chest, random, new ItemStack(Items.iron_ingot, 3 + random.nextInt(5)));
        putRandom(chest, random, new ItemStack(Items.gold_ingot, 1 + random.nextInt(4)));
        putRandom(chest, random, new ItemStack(Items.ender_pearl, 1 + random.nextInt(2)));
        putRandom(chest, random, new ItemStack(Items.experience_bottle, 2 + random.nextInt(4)));
        putRandom(chest, random, new ItemStack(Items.diamond, 1 + random.nextInt(2)));
        if (theme == 1) putRandom(chest, random, new ItemStack(Items.blaze_rod, 1 + random.nextInt(2)));
        if (theme == 2) putRandom(chest, random, new ItemStack(Items.spider_eye, 2 + random.nextInt(4)));
        if (DungeonsDimension.dungeonKey != null) putRandom(chest, random, new ItemStack(DungeonsDimension.dungeonKey));
    }

    private void putRandom(TileEntityChest chest, Random random, ItemStack stack) {
        int slot = random.nextInt(chest.getSizeInventory());
        for (int tries = 0; tries < chest.getSizeInventory(); tries++) {
            if (chest.getStackInSlot(slot) == null) {
                chest.setInventorySlotContents(slot, stack);
                return;
            }
            slot = (slot + 1) % chest.getSizeInventory();
        }
    }
}
