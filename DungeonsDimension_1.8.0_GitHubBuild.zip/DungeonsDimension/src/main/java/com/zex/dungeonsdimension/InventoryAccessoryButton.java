package com.zex.dungeonsdimension;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraftforge.client.event.GuiScreenEvent;

/** Adds a small accessory button to the vanilla player inventory. */
public class InventoryAccessoryButton {
    private static final int BUTTON_ID = 17310;
    @SubscribeEvent public void onInitGui(GuiScreenEvent.InitGuiEvent.Post event) {
        if (event.gui instanceof GuiInventory) {
            int x = (event.gui.width - 176) / 2;
            int y = (event.gui.height - 166) / 2;
            event.buttonList.add(new GuiButton(BUTTON_ID, x + 132, y + 5, 38, 20, "Joias"));
        }
    }
    @SubscribeEvent public void onAction(GuiScreenEvent.ActionPerformedEvent.Post event) {
        if (event.gui instanceof GuiInventory && event.button != null && event.button.id == BUTTON_ID) {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.thePlayer != null) mc.thePlayer.openGui(DungeonsDimension.INSTANCE, DungeonsGuiHandler.ACCESSORIES_GUI, mc.theWorld, 0, 0, 0);
        }
    }
}
