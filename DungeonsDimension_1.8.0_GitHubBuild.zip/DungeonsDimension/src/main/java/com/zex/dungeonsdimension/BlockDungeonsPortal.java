package com.zex.dungeonsdimension;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.world.World;
import net.minecraftforge.common.DimensionManager;

/** Portal surface activated by the Sun Crystal block. */
public class BlockDungeonsPortal extends Block {
    public BlockDungeonsPortal() {
        super(Material.portal);
        setBlockName("dungeonsPortal");
        setBlockTextureName(DungeonsDimension.MODID + ":dungeons_portal");
        setBlockUnbreakable();
        setResistance(6000000.0F);
        setLightLevel(0.8F);
        setCreativeTab(null);
    }

    @Override public boolean isOpaqueCube() { return false; }
    @Override public boolean renderAsNormalBlock() { return false; }
    @Override public int getRenderBlockPass() { return 1; }
    @Override public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int x, int y, int z) { return null; }

    @Override public void onEntityCollidedWithBlock(World world, int x, int y, int z, Entity entity) {
        if (world.isRemote || !(entity instanceof EntityPlayer) || entity.isDead) return;
        EntityPlayer player = (EntityPlayer) entity;
        if (player.timeUntilPortal > 0) return;
        player.timeUntilPortal = 80;
        int target = player.dimension == DungeonsDimension.DIMENSION_ID ? 0 : DungeonsDimension.DIMENSION_ID;
        if (DimensionManager.getWorld(target) == null) DimensionManager.initDimension(target);
        player.travelToDimension(target);
    }
}
